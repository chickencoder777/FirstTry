/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group8.objects;

import com.group8.framework.GameObject;
import com.group8.framework.ObjectId;
import com.group8.framework.Texture;
import com.group8.window.Animation;
import com.group8.window.Game;
import com.group8.window.Controller;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.group8.objects.Egg;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileWriter;


/**
 *
 * @author mluo
 */
public class Player extends GameObject{
    private float width = 48, height = 48;
    private float gravity = 0.5f;
    private final float MAX_SPEED = 10;
    private Controller controller;
    int numOfEggs = 0;
    String path;
    boolean append_to_file = false;
    
    
    Texture tex = Game.getInstance();
    
    private Animation playerWalk;
    
    public Player(float x, float y, Controller controller, ObjectId id){
        super(x, y, id);
        this.controller = controller;
        
        playerWalk = new Animation(10, tex.player[1], tex.player[2]);
    }
    
    
    

   
    public void tick(LinkedList<GameObject> object) {
        x += velX;
        y += velY;
        
        if(falling || jumping){
            velY += gravity;
            
            if(velY > MAX_SPEED){
                velY = MAX_SPEED;
            }
        }
        
        if(climbingUp) {
            velY = 0;
            falling = false;
        }
        
        Collision(object);
        
        
        playerWalk.runAnimation();
    }
    float xVal = 500;
    float yVal = 0;
    int health = 3;
    

    public void Collision(LinkedList<GameObject> object){
        for (int i = 0; i < controller.object.size(); i++){
            GameObject tempObject = controller.object.get(i);
            
            if(tempObject.getId() == ObjectId.Floor){
                //Top
                /*if(getBoundsTop().intersects(tempObject.getBounds())){
                    y = tempObject.getY() + 32;
                    velY = 0;
                }*/
                //Bottom
                if(getBounds().intersects(tempObject.getBounds())){
                    y = tempObject.getY() - height;
                    velY = 0;
                    falling = false;
                    jumping = false;
                }
                else {
                    falling = true;
                }
                //Right
                if(getBoundsRight().intersects(tempObject.getBounds())){
                    x = tempObject.getX() - width;
                }
                //Left
                if(getBoundsLeft().intersects(tempObject.getBounds())){
                    x = tempObject.getX() + 32;
                }
            }
            
            if (tempObject.getId() == ObjectId.Chickens){
                if (getBounds().intersects(tempObject.getBounds())){
                    health = health - 1;
                    
                    try{
                        FileWriter writer = new FileWriter ("src//HealthFile.txt", true);
                        writer.write(String.valueOf(health));
                        writer.write("\r\n");
                        writer.close();
                    }
                    catch (IOException e){
                        e.printStackTrace();
                    }
                    
                    controller.removeObject(tempObject);
                    
                }
                if(getBoundsRight().intersects(tempObject.getBounds())){
                    x = tempObject.getX() - width;
                    health = health - 1;
                    
                    try{
                        FileWriter writer = new FileWriter("src//HealthFile.txt", true);
                        writer.write(String.valueOf(health));
                        writer.write("\r\n");
                        writer.close();
                        
                    }
                    catch (IOException e){
                        e.printStackTrace();
                    }
                    
                    /*System.out.println(xVal);
                    System.out.println(yVal);*/
                    //controller.removeObject(tempObject);
                    int xPos = (int)tempObject.getX();
                    tempObject.setX(xPos + 100);
                    
                    
                }
                //Left
                if(getBoundsLeft().intersects(tempObject.getBounds())){
                    x = tempObject.getX() + 32;
                    health = health - 1;
                    
                    try{
                        FileWriter writer = new FileWriter("src//HealthFile.txt", true);
                        writer.write(String.valueOf(health));
                        writer.write("\r\n");
                        writer.close();
                        
                    }
                    catch (IOException e){
                        e.printStackTrace();
                    }
                    
                    int xPos = (int)tempObject.getX();
                    tempObject.setX(xPos - 100);
                    //controller.removeObject(tempObject);
                    
                    
                                       
                    //Rectangle right1 = new Rectangle((int)xVal,(int)yVal, 32, 32);
                }
                
            }
            if (tempObject.getId() == ObjectId.Egg)
            {
                if(getBounds().intersects(tempObject.getBounds())){
                    /*float xVal = tempObject.getX();
                    float yVal = tempObject.getY();
                    System.out.println(xVal);
                    System.out.println(yVal);*/
                    controller.removeObject(tempObject);
                    numOfEggs = numOfEggs + 1;
                    tempObject.setNumEggs(numOfEggs);
                    System.out.println(numOfEggs);
                    
                    
                    
                    
                    y = tempObject.getY() - height;
                    velY = 0;
                    falling = false;
                    jumping = false;
                    
                    try{
                        FileWriter writer = new FileWriter("src//MyFile.txt", true);
                        writer.write(String.valueOf(numOfEggs));
                        writer.write("\r\n");
                        writer.close();
                        
                    }
                    catch (IOException e){
                        e.printStackTrace();
                    }
                    
                    
                    
                }
                else {
                    falling = true;
                }
                //Right
                if(getBoundsRight().intersects(tempObject.getBounds())){
                    x = tempObject.getX() - width;
                    /*float xVal = tempObject.getX();
                    float yVal = tempObject.getY();*/
                    controller.removeObject(tempObject);
                    
                    numOfEggs = numOfEggs + 1;
                    tempObject.setNumEggs(numOfEggs);
                    System.out.println(numOfEggs);
                    
                    try{
                        FileWriter writer = new FileWriter("src//MyFile.txt", true);
                        writer.write(String.valueOf(numOfEggs));
                        writer.write("\r\n");
                        writer.close();
                        
                    }
                    catch (IOException e){
                        e.printStackTrace();
                    }
                    
                    /*System.out.println(xVal);
                    System.out.println(yVal);*/
                    
                    
                }
                //Left
                if(getBoundsLeft().intersects(tempObject.getBounds())){
                    x = tempObject.getX() + 32;
                    controller.removeObject(tempObject);
                    /*System.out.println(xVal);
                    System.out.println(yVal);*/
                    numOfEggs = numOfEggs + 1;
                    tempObject.setNumEggs(numOfEggs);
                    System.out.println(numOfEggs);
                    
                    try{
                        FileWriter writer = new FileWriter("src//MyFile.txt", true);
                        writer.write(String.valueOf(numOfEggs));
                        writer.write("\r\n");
                        writer.close();
                        
                    }
                    catch (IOException e){
                        e.printStackTrace();
                    }
                    
                    
                                       
                    //Rectangle right1 = new Rectangle((int)xVal,(int)yVal, 32, 32);
                }
                
            }
            if(tempObject.getId() == ObjectId.Ladder){
                //Top
                /*if(getBoundsTop().intersects(tempObject.getBounds())){
                    y = tempObject.getY() + 32;
                    velY = 0;
                }
                //Bottom
                if(getBounds().intersects(tempObject.getBounds())){
                    y = tempObject.getY() - height;
                    velY = 0;
                    falling = false;
                    jumping = false;
                }else {
                    falling = true;
                }*/
                //Right
                /*if(getBoundsRight().intersects(tempObject.getBounds())){
                   // x = tempObject.getX() - width;
                   //velY = -5;
                }
                //Left
                if(getBoundsLeft().intersects(tempObject.getBounds())){
                    //x = tempObject.getX() + 32;
                }*/
            }
        }
    }
   
    public void render(Graphics g) {
        
        
        
        g.setColor(Color.BLUE);
        //g.fillRect((int)x, (int)y, (int)width, (int)height);
        
        if (velX != 0){
            playerWalk.drawAnimation(g, (int)x, (int)y, 48, 48);
        }else{
            g.drawImage(tex.player[0], (int)x, (int)y, 48, 48, null);
        }
        
        g.fillRect((int)xVal, (int)yVal, 32, 32);
    }

 
    public Rectangle getBounds() {
        return new Rectangle((int)((int)x + (width/2 - (width/2)/2)), (int)((int)y + (height/2)), (int)width/2, (int)height/2);
    }
    
    public Rectangle getBoundsRight() {
        return new Rectangle((int)((int)x + width - 5), (int)y+5, (int)5, (int)height-10);
    }
    
    public Rectangle getBoundsLeft() {
        return new Rectangle((int)x, (int)y+5, (int)5, (int)height-10);
    }
    
    public Rectangle getBoundsTop() {
        return new Rectangle((int)((int)x + (width/2 - (width/2)/2)), (int)y, (int)width/2, (int)height/2);
    }
}
