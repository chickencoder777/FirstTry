/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group8.objects;

import com.group8.framework.GameObject;
import com.group8.framework.ObjectId;
import com.group8.framework.Texture;
import com.group8.window.Animation;
import com.group8.window.Game;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.LinkedList;
import javafx.animation.PathTransition;
import com.group8.window.Controller;


public class Chickens extends GameObject{
    
     
     public float gravity = 0.5f;
     public final float MAX_SPEED = 10;
     private Controller controller;
     
     PathTransition transition = new PathTransition();
     /*transition.setNode(chickens);
     transition.setDuration(Duration.seconds[3]);
     transition.setPath(status);*/
     
     int originalPos;
     
   
    
    
     
     
     
     Texture tex = Game.getInstance();
         
    
     private Animation playerWalk;
     int numOfTimesCalled = 0;
     
    public Chickens(float x, float y, Controller controller, ObjectId id){
        super(x, y, id);
        this.controller = controller;
        if (numOfTimesCalled == 0){
            originalPos = (int)x;
        }
        numOfTimesCalled = numOfTimesCalled + 1;
        System.out.println(numOfTimesCalled);
        
        

    
        playerWalk = new Animation(10, tex.chickens[0], tex.chickens[1], tex.chickens[2], tex.chickens[3], tex.chickens[4], tex.chickens[5], tex.chickens[6]);
    }

   
    public void tick(LinkedList<GameObject> object) {
        
         x += velX;
         y += velY;
         
         /*if(falling || jumping){
            velY += gravity;
            
            if(velY > MAX_SPEED){
                velY = MAX_SPEED;
            }
        }*/
         
         Collision(object);
         
        
         playerWalk.runAnimation();
        
         
        
    
    }

    
    public void render(Graphics g) {
        
        //g.setColor(Color.LIGHT_GRAY);
        //g.fillOval((int)x, (int)y + 20, 24, 12);
        
        if (velX != 0){
            playerWalk.drawAnimation(g, (int)x, (int) y);
        }
        else{
            g.drawImage(tex.chickens[0], (int)x, (int)y, 55, 40, null);
        }
    } 
    private float width = 48, height = 48;
    

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, 32, 32);
    }
    public Rectangle getBoundsTop() {
        return new Rectangle((int)((int)x + (width/2 - (width/2)/2)), (int)y, (int)width/2, (int)height/2);
    }
    public Rectangle getBoundsBottom() {
        return new Rectangle((int)((int)x + (width/2 - (width/2)/2)), (int)((int)y + (height/2)), (int)width/2, (int)height/2);
    }
    
    public void checkPosition (int distance){
        
        
        if (distance == x + 100 )
        {
            velX = 1;
        }
        if (distance == x)
        {
            velX = -1;
        }
    }
    
    
    // Problem is that you are finding the position of the blocks, not chickens....
    
    
    
    public void Collision(LinkedList<GameObject> object){
        for (int i = 0; i < controller.object.size(); i++){
            GameObject tempObject = controller.object.get(i);
            
            /*if(tempObject.getId() == ObjectId.Floor){
                //Top
                /*if(getBoundsTop().intersects(tempObject.getBounds())){
                    y = tempObject.getY() + 32;
                    velY = 0;
                }
                //Bottom
                if(getBounds().intersects(tempObject.getBounds())){
                    y = tempObject.getY() - height;
                    velY = 0;
                    falling = false;
                    jumping = false;
                }
                else {
                    falling = true;
                }
                //Right
                if(getBoundsRight().intersects(tempObject.getBounds())){
                    x = tempObject.getX() - width;
                    
                   
                }
                //Left
                if(getBoundsLeft().intersects(tempObject.getBounds())){
                    x = tempObject.getX() + 32;
                    
                    
                }
                if (getBoundsBottom().intersects(tempObject.getBounds())){
                    x = tempObject.getX() + 32;
                }
            }*/
            
            if (tempObject.getX() == originalPos - 300)
            {       
                velX = 1;
            }
            if (tempObject.getX() == originalPos)
            {
                velX = -1;
            }
            
            
            
            
            }
            
            
        }
    
    
    public Rectangle getBoundsRight() {
        return new Rectangle((int)((int)x + width - 5), (int)y+5, (int)5, (int)height-10);
    }
    
    public Rectangle getBoundsLeft() {
        return new Rectangle((int)x, (int)y+5, (int)5, (int)height-10);
    }
    
    
    

    
    
    
}
