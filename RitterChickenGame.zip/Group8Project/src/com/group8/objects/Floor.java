/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group8.objects;

import com.group8.framework.GameObject;
import com.group8.framework.ObjectId;
import com.group8.framework.Texture;
import com.group8.window.Game;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

/**
 *
 * @author mluo
 */
public class Floor extends GameObject{
    
    Texture tex = Game.getInstance();
    private int type;
    
    public Floor(float x, float y, int type, ObjectId id){
        super(x, y, id);
        this.type = type;
    }

   
    public void tick(LinkedList<GameObject> object) {
    
    }

    
    public void render(Graphics g) {
        
        //g.setColor(Color.white);
        //g.drawRect((int)x, (int)y, 32, 32);
        if (type == 0) {//regular floor
            g.drawImage(tex.floor[0], (int)x, (int)y, 55, 40, null);
        }
        if (type == 1) {//floor with ladder
            g.drawImage(tex.floor[1], (int)x, (int)y, 55, 40, null);
        }
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, 32, 32);
    }

}