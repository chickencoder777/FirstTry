/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group8.objects;

import com.group8.framework.GameObject;
import com.group8.framework.ObjectId;
import com.group8.framework.Texture;
import com.group8.window.Game;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

/**
 *
 * @author User
 */
public class Timer extends GameObject {
    
     Texture tex = Game.getInstance();
     int time;
     int timeMinutes;
     
     public void timeRetrival (int time, int timeMinutes){
         
     }
    
    public Timer(float time, float timeMinutes, ObjectId id){
        super(time, timeMinutes, id);
        
    }

   
    public void tick(LinkedList<GameObject> object) {
    
    }

    
    public void render(Graphics g) {
        
        /*g.setColor(Color.BLUE);
        g.fillRect(12, 12, 100, 24);
        
        g.setColor(Color.BLACK);
        g.drawString("Timer: " +timeMinutes+ ":" +time, 25, 25);*/
        //g.drawImage(tex.egg, (int)x, (int)y, 32, 32, null);
           
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, 32, 32);
    }
    
}
