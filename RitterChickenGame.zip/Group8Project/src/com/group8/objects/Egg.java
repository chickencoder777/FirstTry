/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group8.objects;

import com.group8.framework.GameObject;
import com.group8.framework.ObjectId;
import com.group8.framework.Texture;
import com.group8.window.Game;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

/**
 *
 * @author mluo
 */
public class Egg extends GameObject{
    int numEggs;
    
    Texture tex = Game.getInstance();
    
    public Egg(float x, float y, ObjectId id){
        super(x, y, id);
    }
    public void setNumEgg(int numEggs){
            
    }
    
    public int getNumEgg(int numEggs){
        return numEggs;
    }

   
    public void tick(LinkedList<GameObject> object) {
    
    }

    
    public void render(Graphics g) {
        
        g.setColor(Color.LIGHT_GRAY);
        g.fillOval((int)x, (int)y + 16, 32, 24);
        //g.drawImage(tex.egg, (int)x, (int)y, 32, 32, null);
           
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, 32, 32);
    }

}