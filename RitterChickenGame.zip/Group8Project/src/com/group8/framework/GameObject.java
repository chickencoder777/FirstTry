/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group8.framework;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

/**
 *
 * @author mluo
 */
public abstract class GameObject {
    
    protected float x, y;
    protected float velX = 0, velY = 0;
    protected ObjectId id;
    protected boolean falling = true;
    protected boolean jumping = false;
    protected boolean climbingUp = false;
    protected boolean climbingDown = false;
    protected int numOfEggsCollected;
    
    public GameObject(float x, float y, ObjectId id){
        this.x = x;
        this.y = y;
        this.id = id;
    }
    
    public abstract void tick(LinkedList<GameObject> object);
    public abstract void render(Graphics g);
    public abstract Rectangle getBounds();
    
    public void setNumEggs(int numOfEggs){
        this.numOfEggsCollected = numOfEggs;
    }
    public int getNumEgg(){
        return numOfEggsCollected;
    }
    
    public float getX(){
        return x;
    }
    
    public float getY(){
        return y;
    }
    public void setX(float x){
        this.x = x;
    }
    public void setY(float y){
        this.y = y;
    }
        
    public float getVelX(){
        return velX;
    }
    
    public float getVelY(){
        return velY;
    }
    
    public void setVelX(float velX){
        this.velX = velX;
    }
    
    public void setVelY(float velY){
        this.velY = velY;
    }
    
    public ObjectId getId(){
        return id;
    }
    
    public boolean isFalling(){
        return falling;
    }
    
    public void setFalling(boolean falling){
        this.falling = falling;
    }
    
    public boolean isJumping(){
        return jumping;
    }
    
    public void setJumping(boolean jumping){
        this.jumping = jumping;
    }
    
    public boolean isClimbingUp(){
        return climbingUp;
    }
    
    public void setClimbingUp(boolean climbingUp){
        this.climbingUp = climbingUp;
    }
    
    public boolean isClimbingDown(){
        return climbingDown;
    }
    
    public void setClimbingDown(boolean climbingDown){
        this.climbingDown = climbingDown;
    }
}
