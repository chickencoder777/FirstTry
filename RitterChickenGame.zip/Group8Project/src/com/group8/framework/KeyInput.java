/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group8.framework;

import com.group8.window.Controller;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.FileWriter;

/**
 *
 * @author mluo
 */
public class KeyInput extends KeyAdapter {
    
    Controller controller;
    
    public KeyInput(Controller controller){
        this.controller = controller;
    }
    
    
    public void keyPressed(KeyEvent e){
        int key = e.getKeyCode();
        
        for (int i = 0; i < controller.object.size(); i++){
            GameObject tempObject = controller.object.get(i);
            
            if(tempObject.getId() == ObjectId.Player){
                if(key == KeyEvent.VK_RIGHT) tempObject.setVelX(5);
                if(key == KeyEvent.VK_LEFT) tempObject.setVelX(-5);
                if(key == KeyEvent.VK_UP) tempObject.setVelY(-5);
                if(key == KeyEvent.VK_DOWN) tempObject.setVelY(5);
                
                if(key == KeyEvent.VK_SPACE && !tempObject.isJumping()) {
                    tempObject.setJumping(true);
                    tempObject.setVelY(-5);
                }
                
            }
        }
        if(key == KeyEvent.VK_ESCAPE){
            try{
            FileWriter writer = new FileWriter("src//MyFile.txt", true);
            writer.write("0");
            writer.write("\r\n");
            writer.close();
            }
            catch(Exception c){
                System.out.println("Error: " +c);
            }
            try{
            FileWriter writer = new FileWriter("src//HealthFile.txt", true);
            writer.write("3");
            writer.write("\r\n");
            writer.close();
            }
            catch(Exception c){
                System.out.println("Error: " +c);
            }
            
            System.exit(1);
            
        }
        
    }
    
    public void keyReleased(KeyEvent e){
        int key = e.getKeyCode();
        
        for (int i = 0; i < controller.object.size(); i++){
            GameObject tempObject = controller.object.get(i);
            
            if(tempObject.getId() == ObjectId.Player){
                if(key == KeyEvent.VK_RIGHT) tempObject.setVelX(0);
                if(key == KeyEvent.VK_LEFT) tempObject.setVelX(0);
                if(key == KeyEvent.VK_UP) tempObject.setVelY(0);
                if(key == KeyEvent.VK_DOWN) tempObject.setVelY(0);
            }
        }        
    }
}
