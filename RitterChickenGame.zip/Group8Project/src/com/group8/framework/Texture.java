/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group8.framework;

import com.group8.window.BufferedImageLoader;
import java.awt.image.BufferedImage;

/**
 *
 * @author mluo
 */
public class Texture {
    
    SpriteSheet bs, ps, cs;
    
    private BufferedImage block_sheet = null;
    private BufferedImage player_sheet = null;
    private BufferedImage chicken_sheet = null;
    
    public BufferedImage[] floor = new BufferedImage[2];
    public BufferedImage ladder = null;
    public BufferedImage egg = null;
    public BufferedImage seed = null;
    public BufferedImage[] player = new BufferedImage[3];
    public BufferedImage [] chickens = new BufferedImage[7];
    
    public Texture(){
        
        BufferedImageLoader loader = new BufferedImageLoader();
        try{
            //block_sheet = loader.loadImage("/res/block_sheet.png");
            block_sheet = loader.loadImage("/res/filmstrip.png");
            player_sheet = loader.loadImage("/res/chuck.png");
            chicken_sheet = loader.loadImage("/res/transparentChickenSpriteSheet.png");
        } catch(Exception e){
            e.printStackTrace();
        }
        
        bs = new SpriteSheet(block_sheet);
        ps = new SpriteSheet(player_sheet);
        cs = new SpriteSheet(chicken_sheet);
        
        getTexture();
    }
    
    public void getTexture(){
        floor[0] = bs.grabImage(1, 1, 11, 6);//floor
        floor[1] = bs.grabImage(2, 1, 11, 6);//floor + ladder
        
        ladder = bs.grabImage(3, 1, 11, 6);//ladder
        egg = bs.grabImage(4, 1, 11, 6);//egg
        seed = bs.grabImage(5, 1, 11, 6);//seed
        
        //block[0] = bs.grabImage(1, 1, 32, 32);//dirt block
        //block[1] = bs.grabImage(2, 1, 32, 32);//grass block
        
        player[0] = ps.grabImage(1, 1, 11, 19);//idle frame for player
        player[1] = ps.grabImage(2, 1, 11, 19);//walking animation for player
        player[2] = ps.grabImage(3, 1, 11, 19);//walking animation for player
        //player[3] = ps.grabImage(4, 1, 32, 64);//walking animation for player
        //player[4] = ps.grabImage(5, 1, 32, 64);//walking animation for player
        //player[5] = ps.grabImage(6, 1, 32, 64);//walking animation for player
        //player[6] = ps.grabImage(7, 1, 32, 64);//walking animation for player
        
        chickens[0] = cs.grabImage(1, 1, 47, 45);
        chickens[1] = cs.grabImage(2, 1, 47, 45); //walking animation for chicken.
        chickens[2] = cs.grabImage(3, 1, 47, 45);
        chickens[3] = cs.grabImage(4, 1, 47, 45);
        chickens[4] = cs.grabImage(5, 1, 47, 45); //walking animation for chicken.
        chickens[5] = cs.grabImage(6, 1, 47, 45);
        chickens[6] = cs.grabImage(7, 1, 47, 45);
        
        
        
    }
    
}
