/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group8.window;




import com.group8.framework.GameObject;
import com.group8.framework.KeyInput;
import com.group8.framework.ObjectId;
import static com.group8.framework.ObjectId.Timer;
import com.group8.framework.Texture;
import com.group8.objects.Chickens;
import com.group8.objects.Floor;
import com.group8.objects.Player;
import com.group8.objects.Egg;
import com.group8.objects.Ladder;
import com.group8.objects.Seed;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.Random;
import com.group8.objects.Timer;
import java.awt.Font;
import java.util.LinkedList;
import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;


/**
 *
 * @author mluo
 */
public class Game extends Canvas implements Runnable{
    public static int WIDTH;
    public static int HEIGHT;
    private float timeCount;
    private Integer score;
    private Integer worldTimer;
    int time = 0;
    int timeMinutes = 0;
    GameObject tempObject;
    
    int numOfEggs;
    int health;
    
   
    
    Egg egg = new Egg(23, 44, ObjectId.Egg);
    
    
    
    /*LinkedList<GameObject> object;
    
    GameObject tempObject1 = controller.object.get(1);*/
    
    
    
    
    
    
    

    
    private boolean running = false;
    private Thread thread;
    Controller controller;
    static Texture tex;

    
    private BufferedImage level = null;
   
    
    public void init(){
        
        WIDTH = getWidth();
        HEIGHT = getHeight();
        
        tex = new Texture();
        
        BufferedImageLoader loader = new BufferedImageLoader();
        
        level = loader.loadImage("/res/level5.png");
        
        controller = new Controller();
        
        LoadImageLevel(level);
        
        this.addKeyListener(new KeyInput(controller));
        
        
        
    }
    
    
    
   
    
    
    public synchronized void start(){
        if (running){ //To avoid multiple threads running at the same time
            return;
        }
        
        running = true;
        thread = new Thread(this);
        thread.start();
    }
    public void run(){
        
        /*BufferStrategy bs = this.getBufferStrategy();
        if (bs == null){ //Create the BufferStrategy once
            this.createBufferStrategy(3);
            return;
        }
        
        Graphics gap = bs.getDrawGraphics();
        Graphics2D gap2 = (Graphics2D) gap;*/
        
        init();
        this.requestFocus();
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int updates = 0;
        int frames = 0;
        while (running){
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while (delta >= 1){
                tick();
                updates++;
                delta--;
            }
            render();
            frames++;
            
            if(System.currentTimeMillis() - timer > 1000){
                timer += 1000;
                System.out.println("FPS: " + frames + " Ticks: " + updates);
                frames = 0;
                updates = 0;
                time = time + 1;
                
                
                //gap.drawString(String.valueOf(time), 25, 25);
                if (time >= 60)
                {
                    timeMinutes = timeMinutes + 1;
                    time = 0;
                    
                }
                
                /*Scanner in = new Scanner(System.in);
                
                String s = in.nextLine();
                System.out.println(s);
                */
                
                numOfEggs = egg.getNumEgg();
                
               
                
                
                
                
                
                
                //ObjectId.Timer.timeRetrival(time, timeMinutes);
                controller.addObject(new Timer((float)time, (float)timeMinutes, ObjectId.Timer));
                
                
            }
        }
        
    }
    
    private void tick(){
        controller.tick();
    }
    float xPosition;
    float yPosition;
    
    public void getPositions (float xPos, float yPos){
        xPosition = xPos;
        yPosition = yPos;
    }
    
    private void render(){
        
        //numOfEggs = egg.getNumEgg();
        
         // I realize this method is a slow one to determine the number of eggs collected - as the program has to go through all of the data in the text file 
                // each time, but for now this works, and if possible, improvements should be made to use the tempObject.getNumEgg() method, without problems. 
                // THIS NEEDS IMPROVEMENT
                boolean endOfFile;
                endOfFile = false;
                String numOfEggsString;
                
                try { // A try statement is used to read the file.
            
                // A new file reader and buffered reader are used to bring in data from a text file.
                FileReader fr = new FileReader("src//MyFile.txt");
                BufferedReader br = new BufferedReader(fr);
                while (!endOfFile) { // A do while loop is used to continue going through all of the information in the document until the end of the file is reached.
                    numOfEggsString = br.readLine(); // The variable of refNum is initialized as the next line.
                    
                
                if (numOfEggsString == null) {
                    endOfFile = true;
                }
                else{
                    numOfEggs = Integer.parseInt(numOfEggsString);
                }
                }
                    br.close();
                
                }
                catch (Exception e){
                    System.out.println("Error: " +e);
                }
                
                
                boolean endOfFile2;
                endOfFile2 = false;
                String healthString;
                
                try { // A try statement is used to read the file.
            
                // A new file reader and buffered reader are used to bring in data from a text file.
                FileReader fr = new FileReader("src//HealthFile.txt");
                BufferedReader br = new BufferedReader(fr);
                while (!endOfFile2) { // A do while loop is used to continue going through all of the information in the document until the end of the file is reached.
                    healthString = br.readLine(); // The variable of refNum is initialized as the next line.
                    
                
                if (healthString == null) {
                    endOfFile2 = true;
                }
                else{
                    health = Integer.parseInt(healthString);
                }
                }
                    br.close();
                
                }
                catch (Exception e){
                    System.out.println("Error: " +e);
                }
        
        
        BufferStrategy bs = this.getBufferStrategy();
        if (bs == null){ //Create the BufferStrategy once
            this.createBufferStrategy(3);
            return;
        }
        
        Graphics g = bs.getDrawGraphics();
        Graphics2D g2d = (Graphics2D) g;
        /////////////////////////////////
        //draw here
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        
        controller.render(g);
        
        
        g.setColor(Color.LIGHT_GRAY);
        g.fillOval(270, 0, 32, 24);
        
        /*g.setColor(Color.BLUE);
        g.fillRect(12, 12, 100, 25);*/
        g.setFont(new Font ("Monospaced", Font.BOLD, 32));
        
        if (time < 10){
            g.setColor(Color.WHITE);
            g.drawString("TIMER: " +timeMinutes+ ":0" +time, 25, 25);
        }
        else{
            g.setColor(Color.WHITE);
            g.drawString("TIMER: " +timeMinutes+ ":" +time, 25, 25);
        }
        
        g.setColor(Color.WHITE);
        g.setFont(new Font ("Monospaced", Font.BOLD, 32));
        g.drawString(":" +numOfEggs+ "/9", 300, 25);
        g.drawString("Health: " +health, 400, 25);
        
        
        
        
        
        
        /*g.setColor(Color.BLACK);
        g.fillRect((int)xPosition, (int)yPosition, 32, 32);*/
        
        ////////////////////////////////
        g.dispose();
        bs.show();
    }
    
    private void LoadImageLevel(BufferedImage image){
        int w = image.getWidth();
        int h = image.getHeight();
        int scaleX = 55, scaleY = 40;
        System.out.println(w + ", " + h);
        
        for (int xx = 0; xx < w; xx++){
            for (int yy = 0; yy < h; yy++){
                int pixel = image.getRGB(xx, yy);
                int red = (pixel >> 16) & 0xff;
                int green = (pixel >> 8) & 0xff;
                int blue = (pixel) & 0xff;
                
                if(red == 0 && green == 0 && blue == 0){//regular floor
                    controller.addObject(new Floor(xx * scaleX, yy * scaleY, 0, ObjectId.Floor));
                }
                else if(red == 255 && green == 255 && blue == 0){//floor with ladder
                    controller.addObject(new Floor(xx * scaleX, yy * scaleY, 1, ObjectId.Floor));
                }
                else if(red == 255 && green == 0 && blue == 0){//ladder
                    controller.addObject(new Ladder(xx * scaleX, yy * scaleY, ObjectId.Ladder));
                }
                else if(red == 0 && green == 255 && blue == 0){
                    controller.addObject(new Egg(xx * scaleX, yy * scaleY, ObjectId.Egg));
                }
                else if(red == 255 && green == 0 && blue == 255){
                    controller.addObject(new Seed(xx * scaleX, yy * scaleY, ObjectId.Seed));
                }
                else if(red == 0 && green == 0 && blue == 255){
                    controller.addObject(new Player(xx * scaleX, yy * scaleY, controller, ObjectId.Player));
                }
                else if (red == 125 && green == 2 && blue == 78){
                    controller.addObject(new Chickens(xx * scaleX, yy * scaleY, controller, ObjectId.Chickens));
                }
                else if (red == 255 && green == 200 && blue == 0){
                    controller.addObject(new Chickens (xx * scaleX, yy * scaleY, controller, ObjectId.Chickens));
                }
                else if (red == 255 && green == 255 && blue == 255){
                    
                }
                else{
                    controller.addObject(new Chickens (xx * scaleX, yy * scaleY, controller, ObjectId.Chickens));
                    
                }
                controller.addObject(new Timer((float)130, (float)45, ObjectId.Timer));
                
                
               
                
            }
        }
    }
    
    
    //coutdownLabel = new Label(String.format("%03d", worldTimer), new Label);
    
    public static Texture getInstance(){
        return tex;
    }
    
   /* public void update(float dt){
        timeCount += dt;
        if (timeCount>= 1){
            worldTimer --;
            countdownLabel.setText(String.format("%03d", worldTimer));
            timeCountCount = 0;
            
        }
    }*/
    
    public static void main(String args[]){
        new Window(1210,880,"Chuckie Egg", new Game());
    }
    
    
}
