/*
Jessie Ritter
September 14, 2019.
This program outputs a series of information about Jessie Ritter.
*/
package rittergreetings;

/**
 *
 * @author User
 */
public class RitterGreetings {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Each of these lines outputs a piece of information regarding the person.
        System.out.println("About Me:");
        System.out.println("Name: Jessie");
        System.out.println("School: North Hastings High School");
        System.out.println("Favourite Music: Christian");
        System.out.println("Favourite TV Show: The Waltons");
        System.out.println("Favourite Colour: Purple");
        System.out.println("Favourite Animal: Chicken");
        System.out.println("Favourite Quote: 'If God is your reason to live, you have no reason to quit.'");
        System.out.println("That's me!");
    }
    
}
