/*
    Jessie Ritter.
    December 10, 2019.
    This program imports a file containing children's books along with reference numbers of those books, it then outputs the title of the book using linear and binary searches 
    based on user input.
 */

// Importations are used to use certain processes throughout the program.
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;

public class RitterBookSearchFrm extends javax.swing.JFrame {

    /**
     * Creates new form RitterBookSearchFrm
     */
    public RitterBookSearchFrm() {
        initComponents();
    }

    // Two static integers are declared and initialized as 0s.
    static int numLinSearches = 0;
    static int numBinSearches = 0;

    // A method is used to return the position in the array in which the book can be found by reference number.
    public static int sortedLinearSearch(ArrayList<Book> myArray, int target) {
         
        int returnedIndex = -1; // The value of returned index is set to -1 so that it can be returned to the main program if the book cannot be found.
        
        // A for loop is used to go through every item in the array list.
        for (int k = 0; k < myArray.size() - 1; k++) {
            
            
            // A check is done to make sure the target is equal to the reference number.
            if (myArray.get(k).getReferenceNum() == target) {
                numLinSearches++;// The numbers of linear searches is added to by 1.
                
                returnedIndex = k; // If the above statement is true, the value of the returned index is set to this location.
            }
            if (myArray.get(k).getReferenceNum() < 0)
            {
                returnedIndex = -1;
            }

        }
        
        return returnedIndex; // The value of the returned index is returned to the main program.
    }

    // A method is used to complete a binary search through the book's reference numbers.
    public static int binarySearch(ArrayList<Book> myArray, int left, int right, int target) {
        int middle; // An integer is declared.
        

        // A check is done to see if the program is done searching (left has gone past right)
        if (left > right) {
            return -1;
        }

        //The middle index of this portion of the array is determined.
        middle = (left + right) / 2;
        
        numBinSearches++; //This is counted as a search.
        // A check is done to see if the middle term is equal to the target from the user.
        if (myArray.get(middle).getReferenceNum() == target)
        {
            return middle; // If so, this value is returned.
        }
        
        //Another check is done to see if the target is less that the middle value.
        else if (myArray.get(middle).getReferenceNum() > target) {
            
            return binarySearch(myArray, left, middle - 1, target); // If this is the case, the program will now search only the left side of the array.
        } else { //the result was positive, meaning that the target is more than the item examined (after it alphabetically)
            //Thus it searches just the right side of the array
            return binarySearch(myArray, middle + 1, right, target);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblInstruction = new javax.swing.JLabel();
        lblEnterNum = new javax.swing.JLabel();
        lblLinSearch = new javax.swing.JLabel();
        lblBinSearch = new javax.swing.JLabel();
        txtRefNum = new javax.swing.JTextField();
        btnFindIt = new javax.swing.JButton();
        txtLinSearch = new javax.swing.JTextField();
        txtBinSearch = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 153, 0));
        lblTitle.setText("Children's Classics");

        lblInstruction.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        lblInstruction.setForeground(new java.awt.Color(255, 0, 0));
        lblInstruction.setText("The program will find the title of the book based on its reference number.");

        lblEnterNum.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        lblEnterNum.setForeground(new java.awt.Color(255, 153, 0));
        lblEnterNum.setText("Enter the reference number:");

        lblLinSearch.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        lblLinSearch.setForeground(new java.awt.Color(255, 153, 0));
        lblLinSearch.setText("Linear Search:");

        lblBinSearch.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        lblBinSearch.setForeground(new java.awt.Color(255, 153, 0));
        lblBinSearch.setText("Binary Search:");

        txtRefNum.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N

        btnFindIt.setBackground(new java.awt.Color(255, 153, 0));
        btnFindIt.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        btnFindIt.setForeground(new java.awt.Color(255, 0, 0));
        btnFindIt.setText("Find it!");
        btnFindIt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindItActionPerformed(evt);
            }
        });

        txtLinSearch.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N

        txtBinSearch.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Winnie the Pooh.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(lblEnterNum)
                        .addGap(54, 54, 54)
                        .addComponent(txtRefNum, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(75, 75, 75))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnFindIt)
                        .addGap(65, 65, 65)))
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addGap(52, 52, 52))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(lblLinSearch)
                                .addGap(18, 18, 18)
                                .addComponent(txtLinSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 373, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(lblBinSearch)
                                .addGap(18, 18, 18)
                                .addComponent(txtBinSearch))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(259, 259, 259)
                        .addComponent(lblTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(lblInstruction)))
                .addContainerGap(145, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblInstruction)
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblEnterNum)
                            .addComponent(txtRefNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(51, 51, 51)
                        .addComponent(btnFindIt)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLinSearch)
                    .addComponent(txtLinSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBinSearch)
                    .addComponent(txtBinSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFindItActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindItActionPerformed
        // An array list is declared and initialized with the object of book.
        ArrayList<Book> books = new ArrayList<Book>();
        
        // The variables are initialized and declared.
        String name = "";
        String refNumString;
        int refNum;
        boolean endOfFile;
        endOfFile = false;

        try { // A try statement is used to read the file.
            
            // A new file reader and buffered reader are used to bring in data from a text file.
            FileReader fr = new FileReader("src//Booklist.txt");
            BufferedReader br = new BufferedReader(fr);

            while (!endOfFile) { // A do while loop is used to continue going through all of the information in the document until the end of the file is reached.
                refNumString = br.readLine(); // The variable of refNum is initialized as the next line.
                refNum = Integer.parseInt(refNumString);
                
                // An if statement is used to determine if the refNum returns null.
                if (refNumString == null) {
                    endOfFile = true; // If the above statement is true, the boolean of endOfFile is set to true.
                    // An else statement is used.
                } else {
                    // The variable of name is initialized as the next line.
                    name = br.readLine();

                }
                // These variables are passed to the constructor in books in order to add to the array list.
                books.add(new Book(refNum, name));
            }
            br.close(); // The file is closed.
            
        // A catch statement is used to catch any errors.
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
               
        // The variable of target is declared and initialized as the text gotten from the user.
        String target;
        int targetNum;
        target = txtRefNum.getText();
        targetNum = Integer.parseInt(target);

        // The variable of result is declared and initialized as the result from the binary search as a method call is made.
        int result;
        result = binarySearch(books, 0, books.size() - 1, targetNum);

        // An if statement is used to determine if the method found the number or not; and thus outputs a statement to the user detailing the results.
        if (result == -1) {
            txtBinSearch.setText("Book #" + target + " is not in the list.");
        } else {
            txtBinSearch.setText("Found: " + books.get(result).getName() + ". " + numBinSearches + " books processed.");
        }

        // The variable of index is declared and initialized as the result from the linear search as a method call is made.
        int index;
        index = sortedLinearSearch(books, targetNum);

        // An if statement is used to determine if the method found the number of not; and thus outputs a statement to the user detailing the results.
        if (index == -1) {
            txtLinSearch.setText("Book #" + target + " is not in the list.");
        } else {
            txtLinSearch.setText("Found: " + books.get(index).getName() + ". " + numLinSearches + " books processed.");
        }


    }//GEN-LAST:event_btnFindItActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RitterBookSearchFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RitterBookSearchFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RitterBookSearchFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RitterBookSearchFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RitterBookSearchFrm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFindIt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblBinSearch;
    private javax.swing.JLabel lblEnterNum;
    private javax.swing.JLabel lblInstruction;
    private javax.swing.JLabel lblLinSearch;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextField txtBinSearch;
    private javax.swing.JTextField txtLinSearch;
    private javax.swing.JTextField txtRefNum;
    // End of variables declaration//GEN-END:variables
}
