/*
    Jessie Ritter.
    December 10, 2019.
    This class constructs the information for the object of type book and using accessors and mutators returns different sets of information.
 */

/**
 *
 * @author User
 */
public class Book {
    // The variables are declared.
    protected String name;
    protected int refNum;
    
    // A constructor is used to assign values to the variables based on passed values from the main program.
    public Book(int refNumPassed, String namePassed)
    {
        name = namePassed;
        refNum = refNumPassed;
    }
    
    // A to String method is used to create a string outputted this information.
    public String toString (){
        String message = "Name: " +name+ "\nReference Number: " +refNum;
        return message;
    }
    // An accessor is used to return the value of the reference number.
    public int getReferenceNum() {
        return refNum;
    }
    // An accessor is used to return the value of the name.
    public String getName(){
        return name;
    }
    // A mutator is used to set the value of the reference number.
    public void setReferenceNum(int r){
        refNum = r;
    }
    // A mutator is used to set the value of the name.
    public void setName(String n){
        name = n;
    }
    
    
    
   
    
}
